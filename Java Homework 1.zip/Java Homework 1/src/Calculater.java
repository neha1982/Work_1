public class Calculater {
    static int a=12;
    static int b=9;

    static void add(){
        System.out.println (a+b);
    }
    static void sub(){
        System.out.println (a-b);
    }
    static void divide(){
        System.out.println (a/b);
    }
    static void multiply(){
        System.out.println (a*b);
    }
    public static void main (String[]args){
        add();
        divide();
        sub();
        multiply();
    }
}
