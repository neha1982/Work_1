public class Areaofcircle {
    // write a program to calculate area of circle for given radius
    /* Area of circle= pi*r*
    pi =3.14 and r is a radius of circle.
   */
    // sum: Math.pi*radius*radius
    public static void main(String args[]){

        int radius=5;
        double area=Math.PI *radius *radius;

        System.out.println("Area of circle is =" + area);
    }
}
