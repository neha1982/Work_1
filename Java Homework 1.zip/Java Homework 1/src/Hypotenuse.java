public class Hypotenuse {
    //hypotenuse value of triangle when 2 sides given
    public static void main(String[]args){
        int a=8;
        int b=4;
        System.out.println("The hypotenuse of triangle is:" + Math.hypot(a,b));
    }
}
